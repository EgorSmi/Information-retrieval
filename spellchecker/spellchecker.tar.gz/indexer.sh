#!/bin/bash

python3 indexer.py